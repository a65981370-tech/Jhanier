// Función para scroll suave a la siguiente sección
function scrollToNext() {
    document.getElementById('story').scrollIntoView({ behavior: 'smooth' });
}

// Animación de aparición al hacer scroll
const sections = document.querySelectorAll('section');
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, { threshold: 0.1 });

sections.forEach(section => observer.observe(section));

// Comportamiento de botones en la pregunta
const yesBtn = document.getElementById('yesBtn');
const noBtn = document.getElementById('noBtn');
const modal = document.getElementById('modal');
const modalMessage = document.getElementById('modalMessage');
const heartsRain = document.getElementById('heartsRain');

yesBtn.addEventListener('click', () => {
    modalMessage.textContent = 'Sabía que dirías que sí, te amo infinitamente ❤️';
    modal.style.display = 'flex';
    // Animación de lluvia de corazones
    for (let i = 0; i < 20; i++) {
        const heart = document.createElement('div');
        heart.className = 'heart';
        heart.textContent = '❤️';
        heart.style.left = Math.random() * 100 + '%';
        heart.style.animationDelay = Math.random() * 3 + 's';
        heartsRain.appendChild(heart);
        setTimeout(() => heart.remove(), 3000);
    }
});

noBtn.addEventListener('mouseover', () => {
    // Mover el botón de forma divertida
    const x = Math.random() * (window.innerWidth - noBtn.offsetWidth);
    const y = Math.random() * (window.innerHeight - noBtn.offsetHeight);
    noBtn.style.position = 'absolute';
    noBtn.style.left = x + 'px';
    noBtn.style.top = y + 'px';
});

function closeModal() {
    modal.style.display = 'none';
    heartsRain.innerHTML = '';
}